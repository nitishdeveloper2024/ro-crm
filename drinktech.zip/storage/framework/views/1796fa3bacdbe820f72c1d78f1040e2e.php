<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <?php echo e(__("You're logged in!")); ?>

                </div>
            </div>
        </div>
    </div>
    

    <div class="container">
        <h1>Welcome to Your Dashboard</h1>
        <style>
            .col-md-3{
                margin: 5px 0px;
            }
        </style>
        <!-- Displaying the analytics data -->
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Users</div>
                    <div class="card-body">
                        <h4><?php echo e($userCount); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Products Sale Value</div>
                    <div class="card-body">
                        <h4><?php echo e(number_format($totalSale,2)); ?> INR</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Service Sale Value</div>
                    <div class="card-body">
                        <h4><?php echo e(number_format($totalService,2)); ?> INR</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Rental Sale Value</div>
                    <div class="card-body">
                        <h4><?php echo e(number_format($totalRental,2)); ?> INR</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Products</div>
                    <div class="card-body">
                        <h4><?php echo e($userProduct); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Sale</div>
                    <div class="card-body">
                        <h4><?php echo e($userSale); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Parts</div>
                    <div class="card-body">
                        <h4><?php echo e($userPart); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Parts Sale</div>
                    <div class="card-body">
                        <h4><?php echo e($userPartsale); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Complaint</div>
                    <div class="card-body">
                        <h4><?php echo e($userComplaint); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Service</div>
                    <div class="card-body">
                        <h4><?php echo e($userService); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Roles</div>
                    <div class="card-body">
                        <h4><?php echo e($userCount); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Permissions</div>
                    <div class="card-body">
                        <h4><?php echo e($userPermission); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Total Rentals</div>
                    <div class="card-body">
                        <h4><?php echo e($rechargeCount); ?></h4>
                    </div>
                </div>
            </div>
    
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Active Recharges</div>
                    <div class="card-body">
                        <h4><?php echo e($activeRecharges); ?></h4>
                    </div>
                </div>
            </div>
    
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">Expired Recharges</div>
                    <div class="card-body">
                        <h4><?php echo e($expiredRecharges); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Laravel projects\drinktech_backend\resources\views\dashboard.blade.php ENDPATH**/ ?>