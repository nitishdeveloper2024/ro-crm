<!DOCTYPE html>
<html>
<head>
    <title>Recharge <?php echo e($status); ?> Notice</title>
</head>
<body>
    <h1>Dear <?php echo e($recharge->name); ?></h1>
    <p>We regret to inform you that your rental recharge has <?php echo e($status); ?>. Please find the details in the attached PDF.</p>
    <p>Best Regards, <br> Rental Support</p>
</body>
</html>
<?php /**PATH D:\Laravel projects\drinktech_backend\resources\views\emails\recharge_expired.blade.php ENDPATH**/ ?>