<!DOCTYPE html>
<html>
<head>
    <title>Recharge <?php echo e($status); ?> Notice</title>
</head>
<body>
    <h1>Rental Recharge <?php echo e($status); ?> Notice</h1>
    <p><strong>Rental ID:</strong> <?php echo e($recharge->rental_id); ?></p>
    <p><strong>Name:</strong> <?php echo e($recharge->name); ?></p>
    <p><strong>Email:</strong> <?php echo e($recharge->email); ?></p>
    <p>The recharge for your rental has <?php echo e($status); ?>. Please take action accordingly.</p>
</body>
</html>
<?php /**PATH D:\Laravel projects\drinktech_backend\resources\views\pdf\expired_recharge.blade.php ENDPATH**/ ?>