<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    {{-- <title>Invoice - {{ $sale->name }}</title> --}}
</head>
<body>
    {{-- <h1>Invoice for {{ $sale->name }}</h1>
    <p>Price per unit: ₹{{ $sale->price }}</p>
    <p>Quantity: {{ $sale->qty }}</p>
    <p>Discount: ₹{{ $sale->discount }}</p>
    <h3>Total Amount: ₹{{ $sale->final_amt }}</h3> --}}
    hiii
</body>
</html>
