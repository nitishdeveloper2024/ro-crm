
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental Recharge Submitted || Drinktech- NEXTGEN RO</title>
</head>
<body>
    <h2>Dear {{ $recharge->name }},</h2>
    <p>Thank you for submitting your rental. Your Rental ID is <strong>{{ $recharge->rental_id }}</strong>.</p>
    <p>We have attached a PDF with the details of your rental.</p>
    <p>Our team will contact you soon regarding the status of your rental.</p>
    <p>Regards,<br>Support Team</p>
</body>
</html>
